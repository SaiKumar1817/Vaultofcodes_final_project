import os
TODO_FILE = "todo.txt"

def load_todos():
    if os.path.exists(TODO_FILE):
        with open(TODO_FILE, 'r') as file:
            return [line.strip() for line in file]
    return []

def save_todos(todos):
    with open(TODO_FILE, 'w') as file:
        for todo in todos:
            file.write(todo + '\n')

def display_todos(todos):
    if not todos:
        print("No to-do items.")
    else:
        for idx, todo in enumerate(todos, 1):
            print(f"{idx}. {todo}")

def add_todo():
    todo = input("Enter a new to-do item: ")
    todos.append(todo)
    save_todos(todos)
    print("To-do item added.")

def remove_todo():
    display_todos(todos)
    try:
        index = int(input("Enter the number of the to-do item to remove: ")) - 1
        if 0 <= index < len(todos):
            removed = todos.pop(index)
            save_todos(todos)
            print(f"Removed to-do item: {removed}")
        else:
            print("Invalid index.")
    except ValueError:
        print("Please enter a valid number.")

def main():
    global todos
    todos = load_todos()
    while True:
        print("\nTo-Do List:")
        display_todos(todos)
        print("\n select your Options:")
        print("1. Add to-do item")
        print("2. Remove to-do item")
        print("3. Exit")

        choice = input("Enter your choice: ")
        if choice == '1':
            add_todo()
        elif choice == '2':
            remove_todo()
        elif choice == '3':
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
